//I pledge my honor that I have abided by the Stevens Honor System
//Matt Evanego 2/28/21

const people = require("./people");
const work = require("./work");

async function main(){
    try{
        const peopledata = await people.getPersonById(999);
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.getPersonById(-1);
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.howManyPerState("NJ");
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.howManyPerState("NP");
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.peopleMetrics();
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.personByAge(0);
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.personByAge(43);
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.personByAge(500);
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const peopledata = await people.personByAge(5000);
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.fourOneOne('240-144-7553');
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.fourOneOne('240-144-755');
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.fourOneOne('2401447553');
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.fourOneOne();
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.whereDoTheyWork('299-63-8866');
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.whereDoTheyWork('277-85-0056');
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.whereDoTheyWork("264-67-0084");
        console.log (workData);
    }catch(e){
        console.log (e);
    }
    try{
        const workData = await work.whereDoTheyWork("277850056");
        console.log (workData);
    }catch(e){
        console.log (e);
    }

}

//call main
main();
