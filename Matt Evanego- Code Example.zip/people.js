//I pledge my honor that I have abided by the Stevens Honor System
//Matt Evanego 2/28/21
const axios = require('axios').default;

async function getPeople(){
    const { data } = await axios.get('https://gist.githubusercontent.com/graffixnyc/31e9ef8b7d7caa742f56dc5f5649a57f/raw/43356c676c2cdc81f81ca77b2b7f7c5105b53d7f/people.json');
    return data 
  }

async function getPersonById(id){
    if(id === undefined) throw "An Id must be supplied.";
    if(typeof id !== 'number') throw "The id must be a number.";

    let idfound = false;
    let returnIndex = 0;
    const peopleData = await getPeople();

    for(let i = 0; i < peopleData.length; i++){
        if(peopleData[i].id == id)
        {
            returnIndex = i;
            idfound = true;
        }
    }

    if(!idfound) throw "ID must be found in the people data."

    return peopleData[returnIndex];
}

async function howManyPerState(stateAbbrv){
    if(stateAbbrv === undefined) throw "A state abbrv must be supplied."
    if (typeof stateAbbrv !== 'string') throw "State abbrv must be a string."
    const peopleData = await getPeople();

    let count = 0;
    for(let i = 0; i < peopleData.length; i++){
        if(peopleData[i].address.state == stateAbbrv){
            count++;
        }
    }

    if(count == 0) throw "Enter a state abbrv that has people in it."

    return count;
}

async function personByAge(index){
    //0 is oldest, 999 youngest
    if(index === undefined) throw "An Id must be supplied.";
    if(typeof index !== 'number') throw "The id must be a number.";
    const peopleData = await getPeople();
    if(peopleData.length == 0) throw "There must be people in the JSON file."

    if(index > peopleData.length) throw "Index must be within the range of people data."

    peopleData.sort(function(a,b) { 
        return new Date(a.date_of_birth).getTime() - new Date(b.date_of_birth).getTime() 
    })

    let returnObj = {};
    returnObj.first_name = peopleData[index].first_name;
    returnObj.last_name = peopleData[index].last_name;
    returnObj.date_of_birth = peopleData[index].date_of_birth;
    returnObj.age = getAge(peopleData[index].date_of_birth);
    return returnObj;
}

async function peopleMetrics(){
    //total-letters
    //total vowels
    //total consonants
    //longest name
    //shortest name
    //most repeating city
    //average age
    const vowels = ["a","e","i","o","u"];
    const consonants = ["b","c","d","f","g","h","j","k","l","m","n","p","q","r","s","t","v","w","x","y","z"];

    let countVowels = 0;
    let countConsonants = 0;
    let totalLetters = 0;
    let mostRepeatingCity = "";
    let averageAge = 0;

    const peopleData = await getPeople();
    if(peopleData.length == 0) throw "There must be people in the JSON file."
    let longestName = peopleData[0].first_name + " " + peopleData[0].last_name;
    let shortestName = longestName;

    let longestNameLength = peopleData[0].first_name.length + peopleData[0].last_name.length;
    let shortestNameLength = longestNameLength;
    let currFirst = "";
    let currLast = "";
    let tempCityArray = [];
    //Consonants and Vowels
    for(let i = 0; i < peopleData.length; i++){
        currFirst = peopleData[i].first_name;
        
        for(let j = 0; j < currFirst.length; j++){
            if(vowels.includes(currFirst.charAt(j)))
            {
                countVowels = countVowels + 1;
            }
            else if(consonants.includes(currFirst.charAt(j))){
                countConsonants = countConsonants + 1;
            }
        }

        currLast = peopleData[i].last_name;
        for(let j = 0; j < currFirst.length; j++){
            if(vowels.includes(currLast.charAt(j)))
            {
                countVowels = countVowels + 1;
            }
            else if(consonants.includes(currLast.charAt(j))){
                countConsonants = countConsonants + 1;
            }
        }
        //Done counting -> shortest and longest
        if(currFirst.length + currLast.length > longestNameLength){
            longestNameLength = currFirst.length + currLast.length;
            longestName = currFirst + " " + currLast;
        }
        else if(currFirst.length + currLast.length < shortestNameLength){
            shortestNameLength = currFirst.length + currLast.length;
            shortestName = currFirst + " " + currLast;
        }

        //Average Age
        averageAge = averageAge + getAge(peopleData[i].date_of_birth);

        //City Mode
        tempCityArray.push(peopleData[i].address.city);
    }

    mostRepeatingCity = mode(tempCityArray);
    averageAge = averageAge / peopleData.length;
    totalLetters = countConsonants + countVowels;

    let returnObj = {};
    returnObj.totalLetters = totalLetters;
    returnObj.totalVowels = countVowels;
    returnObj.totalConsonants = countConsonants;
    returnObj.longestName = longestName;
    returnObj.shortestName = shortestName;
    returnObj.mostRepeatingCity = mostRepeatingCity;
    returnObj.averageAge = averageAge;

    return returnObj;
}

function getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

function mode(arr){
    return arr.sort((a,b) =>
          arr.filter(v => v===a).length
        - arr.filter(v => v===b).length
    ).pop();
}

module.exports = {
    personByAge,
    peopleMetrics,
    howManyPerState,
    getPersonById,

    getPeople
};