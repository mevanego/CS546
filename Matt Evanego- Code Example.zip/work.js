//I pledge my honor that I have abided by the Stevens Honor System
//Matt Evanego 2/28/21
const axios = require('axios').default;
const people = require('./people');

async function getPeople(){
    const { data } = await axios.get('https://gist.githubusercontent.com/graffixnyc/31e9ef8b7d7caa742f56dc5f5649a57f/raw/43356c676c2cdc81f81ca77b2b7f7c5105b53d7f/people.json')
    return data // this will be the array of people objects
  }

async function getWork(){
    const { data } = await axios.get('https://gist.githubusercontent.com/graffixnyc/febcdd2ca91ddc685c163158ee126b4f/raw/c9494f59261f655a24019d3b94dab4db9346da6e/work.json');
    return data // this will be the array of people objects
  }

async function listEmployees(){

    const workData = await getWork();
    
    let returnArr = [workData.length];
    let employeeArr = [];

    for(let j = 0; j < workData.length; j++){
        let employeeIds = workData[j].employees;
        returnArr[j] = {};
        returnArr[j].company_name = workData[j].company_name;
        let currPerson;
        for(let i = 0; i < employeeIds.length; i++){
            currPerson = await people.getPersonById(employeeIds[i]);
            employeeArr[i] = {};
            employeeArr[i].first_name = currPerson.first_name;
            employeeArr[i].last_name = currPerson.last_name;
        }

        returnArr[j].employees = employeeArr;
        employeeArr = [];
    }

    return returnArr;
}

async function fourOneOne(phoneNumber){
    if(!phoneNumber) throw "You must supply a phone number.";
    if(typeof phoneNumber !== 'string') throw "The phone number must be a string";

    const workData = await getWork();
    
    //Checking that phone number is in the correct format
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if(!(phoneNumber.match(phoneno))) throw "The phone number must be in the correct form.";
    
    let returnObj = {}

    for(let i = 0; i < workData.length; i++){
        if(workData[i].company_phone === phoneNumber){
            returnObj.company_name = workData[i].company_name;
            returnObj.company_address = workData[i].company_address;
            return returnObj;
        }
    }

    throw "That number does not exist in the work JSON.";
    //return 0;
}

async function whereDoTheyWork(ssn){

    const workData = await getWork();
    const peopleData = await getPeople();

    if(!ssn) throw "Please provide your ssn, I promise not to steal your identity.";
    if(typeof ssn !== 'string') throw "The ssn must be a string";

    //Checking that ssn is in the correct format
    var ssnChecker = /^\(?([0-9]{3})\)?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
    if(!(ssn.match(ssnChecker))) throw "The ssn must be in the correct form.";

    let personID;
    let personName;
    for(let i = 0; i < peopleData.length; i++){
        if(peopleData[i].ssn === ssn){
            personID = peopleData[i].id;
            personName = peopleData[i].first_name + " " + peopleData[i].last_name;
            break;
        }
    }
    if(!personID) throw "ssn was not found in people data.";
    let company;
    
    for(let i = 0; i < workData.length; i++){
        for(let j = 0; j < workData[i].employees.length; j++){
            if(personID == workData[i].employees[j]) {
                company = workData[i].company_name;
                break;
            }
        }
    }

    
    return personName + " works at " + company + ".";
}

module.exports = {
    listEmployees,
    fourOneOne,
    whereDoTheyWork
};